# 12 Tutorial Enterprise

**Project:** MDANALYSIS
**Upstream:** https://github.com/MDAnalysis/mdanalysis

Content specific to MDANALYSIS in category CHEMICAL_MANUFACTURING.
